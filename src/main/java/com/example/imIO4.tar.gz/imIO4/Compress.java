package com.example.imIO4;/*
 * imIO4
 * Created by Aditya Gholba on 9/2/17.
 */

import com.datatorrent.api.Context;
import com.datatorrent.api.DefaultInputPort;
import com.datatorrent.api.DefaultOutputPort;
import com.datatorrent.common.util.BaseOperator;
import com.datatorrent.lib.io.fs.AbstractFileInputOperator;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class Compress extends BaseOperator
{
    private static final Logger LOG = LoggerFactory.getLogger(Compress.class);
    private String filePathStr;
    private transient ArrayList<byte[]> savedLines = new ArrayList<>();
    private transient BufferedImage bufferedImage = null;
    public final transient DefaultInputPort<String> controlIn = new DefaultInputPort<String>()
    {
        @Override
        public void process(String tuple)
        {
            processControlTuple(tuple);
        }
    };

    private void processControlTuple(final String tuple)
    {
        filePathStr = tuple;
        controlOut.emit(tuple);
        LOG.info(filePathStr);
    }

    public final transient DefaultOutputPort<String> controlOut = new DefaultOutputPort<>();
    public final transient DefaultOutputPort<byte[]> output = new DefaultOutputPort<>();
    public final transient DefaultInputPort<byte[]> input = new DefaultInputPort<byte[]>()
    {

        @Override
        public void process(byte[] tuple)
        {
            processTuple(tuple);
        }
    };

    void processTuple(byte[] byteimage)
    {
        try
        {
            InputStream in = new ByteArrayInputStream(byteimage);
            bufferedImage= ImageIO.read(in);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Iterator<ImageWriter> writers =  ImageIO.getImageWritersByFormatName("jpg");
            ImageWriter writer = writers.next();
            writer.setOutput(new MemoryCacheImageOutputStream(baos));

            ImageWriteParam param = writer.getDefaultWriteParam();
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(0.05f);
            writer.write(null, new IIOImage(bufferedImage, null, null), param);
            writer.dispose();
            byte[] bufim = baos.toByteArray();
            baos.flush();
            baos.reset();
            baos.close();
            output.emit(bufim);
        }
        catch (Exception e){}
    }


}
